﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_005
{
    class Program
    {
        static void Main(string[] args)
        {

            // Пример 5. Пользователь вводит два целых числа numerator и denominator, 
            // которые являются числителем и знаменателем соответственно
            // Нужно выяснить, можно ли сократить эту дробь
            // и если можно, то на какое число
            //   50     25      5     1
            // ----- = ---- = ---- = ---
            //  100     50     10     2

            // https://ru.wikipedia.org/wiki/Наибольший_общий_делитель
            // https://ru.wikipedia.org/wiki/Алгоритм_Евклида
            // Математика 5 класс. Тема "Сокращение дробей"

            Console.Write("\nВведите numerator:");
            double numerator = Convert.ToDouble(Console.ReadLine());

            Console.Write("\nВведите denominator:");
            double denominator = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine($"\n Исходная дробь {numerator}/{denominator}");

            double a = numerator, b = denominator;

            if (a != b) if (a > b) a = a - b; else b = b - a;
            if (a != b) if (a > b) a = a - b; else b = b - a;
            if (a != b) if (a > b) a = a - b; else b = b - a;
            if (a != b) if (a > b) a = a - b; else b = b - a;

            Console.WriteLine($"Можно сократить на {a}");
            
            Console.WriteLine($"Сокращённая дробь {numerator / a}/{denominator / a}");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_610_Intro
{
    class Program
    {
        static void Main(string[] args)
        {
            /// Тема 6.Файлы
            /// Ролик 1.Встроенные методы.Класс Math и Convert, DateTime
            /// Ролик 2.Работа со строками: статический класс String, методы экземпляров
            /// Ролик 3.Работа с файлами: класс File, FileInfo, Directory, DirectoryInfo
            /// Ролик 4.Работа с потоками: StreamWriter и StreamReader
            /// Ролик 5.Расширенная работа со строками: StringReader и StringWriter; изменяемые строки:  StringBuilder
            /// Ролик 6.Домашнее задание

        }
    }
}

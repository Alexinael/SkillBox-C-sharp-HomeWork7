﻿namespace Example_710_Intro
{
    /// <summary>
    /// Кот
    /// </summary>
    public struct Cat
    {
        /// <summary>
        /// Кличка
        /// </summary>
        public string Nickname;

        /// <summary>
        /// Порода
        /// </summary>
        public string Breed;
    }
}

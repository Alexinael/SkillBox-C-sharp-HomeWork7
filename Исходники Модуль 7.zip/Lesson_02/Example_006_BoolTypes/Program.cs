﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_006_BoolTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            // Тип bool может хранить логическое значение, которое принимает значение 
            // правда или ложь. 
            // Эти значения указываются с ключевыми словами true и false

            bool flag = true;   // переменной flag присвоить истину
            flag = false;       // переменной flag присвоить ложь

            // Замечание 
            // Подробное использование этого типа в уроке
            // "Логические операции"


        }
    }
}
